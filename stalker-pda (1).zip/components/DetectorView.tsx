
import React, { useState, useEffect, useMemo } from 'react';
import { ArtifactSpawn, Language } from '../types.ts';
import { translations } from '../i18n.ts';
import { soundManager } from '../services/soundService.ts';

interface DetectorViewProps {
  language: Language;
  userCoords: { lat: number, lng: number } | null;
  activeArtifacts: ArtifactSpawn[];
  onCollect: (spawnId: string) => void;
}

/**
 * Calculates distance between two points in kilometers using Haversine formula
 */
function getDistance(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371; // Radius of the earth in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

export const DetectorView: React.FC<DetectorViewProps> = ({ language, userCoords, activeArtifacts, onCollect }) => {
  const t = translations[language];
  const [pulse, setPulse] = useState(0);

  // Find nearest artifact
  const nearest = useMemo(() => {
    if (!userCoords || activeArtifacts.length === 0) return null;
    
    let minDistance = Infinity;
    let closest: { spawn: ArtifactSpawn, dist: number } | null = null;
    
    activeArtifacts.forEach(s => {
      const d = getDistance(userCoords.lat, userCoords.lng, s.lat, s.lng);
      if (d < minDistance) {
        minDistance = d;
        closest = { spawn: s, dist: d };
      }
    });
    
    return closest;
  }, [userCoords, activeArtifacts]);

  // Handle pulse animation and sound
  useEffect(() => {
    const interval = setInterval(() => {
      setPulse(p => (p + 1) % 100);
      
      if (nearest) {
        // Frequency of sound increases as distance decreases
        // 0.05km (50m) is the max range for sound feedback
        if (nearest.dist < 0.05) {
          soundManager.play('pda_click');
        }
      }
    }, nearest ? Math.max(100, Math.min(2000, nearest.dist * 40000)) : 2000);

    return () => clearInterval(interval);
  }, [nearest]);

  const inRange = nearest && nearest.dist <= 0.005; // 5 meters

  return (
    <div className="flex flex-col h-full w-full bg-[#0c0d0c] text-[#4ade80] font-mono overflow-hidden">
      <div className="p-4 border-b border-[#2a2d2a] bg-[#1a1c1a]/50 flex justify-between items-center">
        <h2 className="text-[12px] font-bold uppercase tracking-[0.2em]">{t.detector} // ECHO-V3</h2>
        <span className="text-[9px] opacity-40">DADOS_ANÔMALOS_ATIVOS: {activeArtifacts.length}</span>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-8 space-y-12">
        {/* Oscilloscope Visualizer */}
        <div className="w-64 h-64 border-2 border-[#4ade80]/20 rounded-full relative flex items-center justify-center">
          <div className="absolute inset-4 border border-[#4ade80]/10 rounded-full"></div>
          <div className="absolute inset-16 border border-[#4ade80]/5 rounded-full"></div>
          
          {/* Pulse Lines */}
          <div 
            className="absolute border border-[#4ade80] rounded-full animate-ping opacity-20"
            style={{ width: `${pulse}%`, height: `${pulse}%` }}
          ></div>
          
          {/* Signal Strength Bars */}
          <div className="flex items-end space-x-1 h-12">
            {[1, 2, 3, 4, 5, 6, 7, 8].map(bar => {
              const signalValue = nearest ? Math.max(0, 100 - (nearest.dist * 2000)) : 0;
              const active = signalValue > (bar * 12);
              return (
                <div 
                  key={bar} 
                  className={`w-3 transition-all duration-300 ${active ? 'bg-[#4ade80] shadow-[0_0_10px_#4ade80]' : 'bg-[#4ade80]/10'}`} 
                  style={{ height: `${bar * 12}%` }}
                ></div>
              );
            })}
          </div>
        </div>

        <div className="w-full max-w-xs space-y-6">
          <div className="text-center space-y-2">
            <h3 className="text-[10px] font-bold text-[#4ade80]/40 uppercase tracking-widest">{t.detector_signal}</h3>
            <div className="text-2xl font-black italic tracking-tighter">
              {nearest ? (100 - Math.min(100, nearest.dist * 2000)).toFixed(1) : "0.0"}%
            </div>
          </div>

          <div className="bg-black/40 border border-[#2a2d2a] p-4 space-y-4">
             <div className="flex justify-between items-center">
                <span className="text-[10px] uppercase opacity-40">{t.detector_distance}</span>
                <span className="text-sm font-bold">
                  {nearest ? (nearest.dist * 1000).toFixed(1) : "---"} m
                </span>
             </div>
             
             <div className="text-center py-2 border-t border-[#2a2d2a]">
                <span className={`text-[10px] font-bold uppercase tracking-widest ${inRange ? 'text-[#4ade80] animate-pulse' : 'text-[#4ade80]/30'}`}>
                  {nearest ? (inRange ? t.detector_in_range : t.detector_out_of_range) : t.detector_searching}
                </span>
             </div>

             <button 
               disabled={!inRange}
               onClick={() => nearest && onCollect(nearest.spawn.id)}
               className={`w-full py-4 text-[11px] font-black uppercase tracking-widest border-2 transition-all transform active:scale-95 ${inRange ? 'bg-[#4ade80] border-[#4ade80] text-black shadow-[0_0_30px_rgba(74,222,128,0.4)]' : 'bg-black border-[#2a2d2a] text-[#4ade80]/20 cursor-not-allowed'}`}
             >
               {t.detector_collect}
             </button>
          </div>
        </div>
      </div>

      <div className="p-4 bg-black/40 border-t border-[#2a2d2a] text-[8px] font-mono opacity-30 flex justify-between">
         <span>SENS_LVL: 88.4%</span>
         <span>FREQ: 14.2 GHz</span>
         <span>VER: ECHO_OS_4.0</span>
      </div>
    </div>
  );
};
