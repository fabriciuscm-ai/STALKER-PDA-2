
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { toMGRS } from '../utils/coords.ts';
import { Language, Artifact, ArtifactSpawn } from '../types.ts';
import { translations } from '../i18n.ts';
import { OnlineStalker } from '../App.tsx';
import { soundManager } from '../services/soundService.ts';
import L from 'leaflet';

interface MapViewProps {
  language: Language;
  isEmission: boolean;
  onAction: (xp: number, factionPoints?: number) => void;
  onArtifactFound: (art: Artifact) => void;
  onlineStalkers: OnlineStalker[];
  artifactsInWorld?: ArtifactSpawn[];
  onCollectItem?: (spawnId: string) => void;
}

type MapTheme = 'monochrome' | 'satellite';

function getDistance(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

export const MapView: React.FC<MapViewProps> = ({ language, isEmission, onAction, onArtifactFound, onlineStalkers, artifactsInWorld, onCollectItem }) => {
  const t = translations[language];
  const [coords, setCoords] = useState<{ lat: number, lng: number } | null>(null);
  const [mgrs, setMgrs] = useState<string>("BUSCANDO...");
  const [mapTheme, setMapTheme] = useState<MapTheme>('monochrome');
  
  const mapRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const stalkerGroupRef = useRef<L.LayerGroup | null>(null);
  const itemGroupRef = useRef<L.LayerGroup | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const rangeCircleRef = useRef<L.Circle | null>(null);

  const nearestArtifactSignal = useMemo(() => {
    if (!coords || !artifactsInWorld || artifactsInWorld.length === 0) return null;
    let min = Infinity;
    const artifacts = artifactsInWorld.filter(a => a.artifact.isArtifact);
    if (artifacts.length === 0) return null;

    artifacts.forEach(a => {
      const d = getDistance(coords.lat, coords.lng, a.lat, a.lng);
      if (d < min) min = d;
    });
    return min < 0.1 ? min : null;
  }, [coords, artifactsInWorld]);

  const updateTileLayer = (theme: MapTheme) => {
    if (!mapRef.current) return;
    if (tileLayerRef.current) tileLayerRef.current.remove();
    const url = theme === 'monochrome' 
      ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
      : 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
    tileLayerRef.current = L.tileLayer(url, { maxZoom: 18 }).addTo(mapRef.current);
  };

  const handleRecenter = () => {
    if (coords && mapRef.current) {
      mapRef.current.setView([coords.lat, coords.lng], 16, { animate: true });
      soundManager.play('pda_click');
    }
  };

  useEffect(() => {
    let watchId: number;
    if ("geolocation" in navigator) {
      watchId = navigator.geolocation.watchPosition((pos) => {
        const newCoords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setCoords(newCoords);
        setMgrs(toMGRS(pos.coords.latitude, pos.coords.longitude));
        
        if (userMarkerRef.current) userMarkerRef.current.setLatLng([newCoords.lat, newCoords.lng]);
        if (rangeCircleRef.current) rangeCircleRef.current.setLatLng([newCoords.lat, newCoords.lng]);
      }, (err) => {
        console.error("GPS Error:", err);
      }, { enableHighAccuracy: true });
    }
    return () => { if (watchId) navigator.geolocation.clearWatch(watchId); };
  }, []);

  useEffect(() => {
    if (coords && !mapRef.current) {
      const map = L.map('real-pda-map', { zoomControl: false, attributionControl: false }).setView([coords.lat, coords.lng], 15);
      mapRef.current = map;
      updateTileLayer(mapTheme);
      stalkerGroupRef.current = L.layerGroup().addTo(map);
      itemGroupRef.current = L.layerGroup().addTo(map);
      
      const userIcon = L.divIcon({ className: 'custom-user-icon', iconSize: [14, 14] });
      userMarkerRef.current = L.marker([coords.lat, coords.lng], { icon: userIcon }).addTo(map);
      
      // Pickup Range Circle (15 meters)
      rangeCircleRef.current = L.circle([coords.lat, coords.lng], {
        radius: 15,
        color: '#4ade80',
        weight: 1,
        fillColor: '#4ade80',
        fillOpacity: 0.1,
        dashArray: '5, 5',
        className: 'pickup-range-circle'
      }).addTo(map);
    }
  }, [coords]);

  useEffect(() => {
    if (mapRef.current && stalkerGroupRef.current) {
      stalkerGroupRef.current.clearLayers();
      onlineStalkers.forEach(s => {
        const icon = L.divIcon({ 
          className: 'custom-stalker-icon', 
          html: `<div class="w-full h-full rounded-full animate-pulse bg-[#4ade80]"></div>`,
          iconSize: [12, 12] 
        });
        L.marker([s.lat, s.lng], { icon })
          .bindPopup(`<div class="p-2 font-mono text-[10px] bg-black text-[#4ade80] border border-[#4ade80]">
            <b>${s.name.toUpperCase()}</b><br/>FACÇÃO: ${s.faction}<br/>SINAL: ${s.signalStrength}%
          </div>`)
          .addTo(stalkerGroupRef.current!);
      });
    }
  }, [onlineStalkers]);

  useEffect(() => {
    if (mapRef.current && itemGroupRef.current && artifactsInWorld) {
      itemGroupRef.current.clearLayers();
      artifactsInWorld.forEach(spawn => {
        const dist = coords ? getDistance(coords.lat, coords.lng, spawn.lat, spawn.lng) : 999;
        const inRange = dist <= 0.015;

        if (spawn.artifact.isArtifact) {
          const artifactIcon = L.divIcon({ 
            className: 'pda-artifact-faint', 
            html: `<div class="w-full h-full rounded-full bg-[#4ade80]/5 border border-[#4ade80]/10 animate-pulse"></div>`,
            iconSize: [30, 30] 
          });
          L.marker([spawn.lat, spawn.lng], { icon: artifactIcon, interactive: false }).addTo(itemGroupRef.current!);
        } else {
          // Highlight items in range with a stronger green and pulse
          const itemIcon = L.divIcon({ 
            className: `pda-item-map ${inRange ? 'item-in-range' : ''}`, 
            html: `
              <div class="w-full h-full flex items-center justify-center bg-black/60 border-2 rounded pda-icon text-[10px] transition-all
                ${inRange ? 'border-[#4ade80] scale-110 shadow-[0_0_15px_#4ade80] animate-bounce' : 'border-[#4ade80]/40 shadow-[0_0_5px_rgba(74,222,128,0.2)]'}"
              >
                ${spawn.artifact.icon}
              </div>
            `,
            iconSize: [24, 24] 
          });
          
          const marker = L.marker([spawn.lat, spawn.lng], { icon: itemIcon }).addTo(itemGroupRef.current!);
          
          marker.on('click', () => {
            if (!coords) return;
            if (inRange) {
              soundManager.play('pda_click');
              if (onCollectItem) onCollectItem(spawn.id);
            } else {
              soundManager.play('pda_click');
              const popup = L.popup({ className: 'pda-popup' })
                .setLatLng([spawn.lat, spawn.lng])
                .setContent(`
                  <div class="p-2 font-mono text-[10px] bg-black text-[#4ade80] border border-[#4ade80] text-center">
                    <div class="text-[12px] mb-1">${spawn.artifact.icon} ${spawn.artifact.name.toUpperCase()}</div>
                    <div class="opacity-60 mb-2">DISTÂNCIA: ${Math.round(dist * 1000)}m</div>
                    <div class="text-[8px] text-red-500 font-bold uppercase tracking-tighter">FORA DE ALCANCE</div>
                  </div>
                `)
                .openOn(mapRef.current!);
            }
          });
        }
      });
    }
  }, [artifactsInWorld, coords, onCollectItem]);

  return (
    <div className={`flex flex-col md:flex-row h-full w-full ${isEmission ? 'hue-rotate-180 brightness-50' : ''}`}>
      <div className={`relative flex-1 bg-[#0c0d0c] overflow-hidden ${mapTheme === 'monochrome' ? 'map-monochrome' : ''}`}>
        <div id="real-pda-map" className="w-full h-full z-0"></div>
        
        {/* Artifact Proximity Warning */}
        {nearestArtifactSignal !== null && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-[1500] pointer-events-none">
            <div className="bg-black/90 border-2 border-[#4ade80] p-4 text-center animate-pulse shadow-[0_0_20px_rgba(74,222,128,0.3)]">
               <h4 className="text-[12px] font-black text-[#4ade80] uppercase tracking-[0.3em]">{t.artifact_nearby}</h4>
               <p className="text-[9px] text-[#4ade80]/60 mt-1 uppercase italic font-bold">REQUER DETECTOR</p>
            </div>
          </div>
        )}

        <div className="absolute top-4 left-4 z-[1000] space-y-2">
          <div className="bg-black/90 border border-[#4ade80]/40 p-2 text-[10px] font-bold text-[#4ade80] flex items-center space-x-2">
             <span className="w-2 h-2 bg-[#4ade80] rounded-full animate-ping"></span>
             <span>REDE_ATIVA: {onlineStalkers.length} DISPOSITIVOS</span>
          </div>
          <div className="bg-black/90 border border-[#2a2d2a] p-2 font-mono text-[#4ade80]/80">
            <div className="text-[7px] uppercase opacity-40 leading-none mb-1">MGRS_COORD_REAL</div>
            <div className="text-[10px] font-bold text-[#4ade80] tracking-widest">{mgrs}</div>
          </div>
        </div>

        <div className="absolute top-4 right-4 z-[1000] flex flex-col space-y-1">
          <div className="flex space-x-1">
            <button onClick={() => setMapTheme('monochrome')} className={`p-2 text-[9px] font-bold border ${mapTheme === 'monochrome' ? 'bg-[#4ade80] text-black border-[#4ade80]' : 'bg-black text-[#4ade80]/60 border-[#2a2d2a]'}`}>MONO</button>
            <button onClick={() => setMapTheme('satellite')} className={`p-2 text-[9px] font-bold border ${mapTheme === 'satellite' ? 'bg-[#4ade80] text-black border-[#4ade80]' : 'bg-black text-[#4ade80]/60 border-[#2a2d2a]'}`}>SAT</button>
          </div>
          <button 
            onClick={handleRecenter} 
            className="w-full bg-black/90 border border-[#4ade80]/40 p-2 text-[10px] font-bold text-[#4ade80] uppercase hover:bg-[#4ade80]/10 flex items-center justify-center space-x-2"
          >
            <span className="pda-icon text-sm">⌖</span>
            <span>CENTRALIZAR</span>
          </button>
        </div>

        <div className="absolute bottom-6 left-6 z-[1000] flex space-x-2">
          <button onClick={() => onAction(10, 5)} className="bg-black/95 border border-[#4ade80]/40 p-3 text-[10px] font-bold text-[#4ade80] uppercase active:scale-95 transition-transform flex items-center space-x-2 hover:bg-[#4ade80]/10">
            <span className="pda-icon">⚠️</span> <span>{t.report_anomaly}</span>
          </button>
        </div>
      </div>
      
      <div className="w-full md:w-72 bg-[#1a1c1a] p-4 border-l border-[#2a2d2a] overflow-y-auto hidden md:block text-shadow-glow">
        <h3 className="text-[11px] font-bold text-[#4ade80] uppercase border-b border-[#4ade80]/20 pb-2 mb-4 tracking-widest">Sinais Locais</h3>
        <div className="space-y-3">
          {onlineStalkers.map((s, idx) => (
            <div key={idx} className="flex items-center space-x-3 p-2 bg-black/40 border border-[#4ade80]/5 rounded group hover:border-[#4ade80]/40 transition-colors">
               <div className="w-1.5 h-1.5 bg-[#4ade80] rounded-full shadow-[0_0_5px_#4ade80]"></div>
               <div className="flex-1">
                 <div className="text-[11px] font-bold text-[#4ade80] uppercase truncate">{s.name}</div>
                 <div className="text-[8px] text-[#4ade80]/40 font-mono">{s.faction.toUpperCase()} // SNR:{s.signalStrength}%</div>
               </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
