
import React, { useState, useRef, useEffect } from 'react';
import { StalkerProfile, Faction, Language } from '../types.ts';
import { FACTION_INFO } from '../constants.tsx';
import { translations } from '../i18n.ts';
import { moderateImage } from '../services/geminiService.ts';
import { soundManager } from '../services/soundService.ts';

interface ProfileViewProps {
  profile: StalkerProfile;
  setProfile: (profile: StalkerProfile) => void;
  isSoundEnabled: boolean;
  setIsSoundEnabled: (enabled: boolean) => void;
}

const MSG_SOUNDS = [
  { id: 'msg_classic', label: 'Rádio Clássico' },
  { id: 'msg_digital', label: 'Digital Bip' },
  { id: 'msg_military', label: 'Alerta Militar' },
  { id: 'msg_custom', label: 'Personalizado 📁' },
];

export const ProfileView: React.FC<ProfileViewProps> = ({ profile, setProfile, isSoundEnabled, setIsSoundEnabled }) => {
  const factionData = FACTION_INFO[profile.faction];
  const t = translations[profile.language];
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(profile.name);
  const [isUploading, setIsUploading] = useState(false);
  const [isAudioLoading, setIsAudioLoading] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);

  const currentMsgSound = profile.config?.msgSound || 'msg_classic';
  const isMuted = profile.config?.isMuted || false;

  useEffect(() => {
    soundManager.setMuted(isMuted);
  }, [isMuted]);

  const handleToggleMute = () => {
    const newMute = !isMuted;
    setProfile({
      ...profile,
      config: { ...profile.config, isMuted: newMute, msgSound: currentMsgSound, customSound: profile.config?.customSound }
    });
    if (!newMute) soundManager.play('pda_click');
  };

  const handleSoundSelect = (soundId: string) => {
    setProfile({
      ...profile,
      config: { ...profile.config, isMuted, msgSound: soundId, customSound: profile.config?.customSound }
    });
    
    if (soundId === 'msg_custom' && profile.config?.customSound) {
      soundManager.playCustom(profile.config.customSound);
    } else {
      soundManager.play(soundId);
    }
  };

  const handleAudioUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024 * 2) { // Max 2MB
        alert("ERRO_HARDWARE: Arquivo muito grande. Máximo 2MB.");
        return;
      }
      setIsAudioLoading(true);
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setProfile({
          ...profile,
          config: { ...profile.config, isMuted, msgSound: 'msg_custom', customSound: base64 }
        });
        setIsAudioLoading(false);
        soundManager.playCustom(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveName = () => {
    if (tempName.trim() && tempName !== profile.name) {
      const historyEntry = { name: profile.name, timestamp: Date.now() };
      setProfile({ 
        ...profile, 
        name: tempName.trim(),
        nameHistory: [historyEntry, ...(profile.nameHistory || [])].slice(0, 10)
      });
      setIsEditingName(false);
      soundManager.play('pda_news');
    } else {
      setIsEditingName(false);
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setIsUploading(true);
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        const modResult = await moderateImage(base64String);
        if (!modResult.safe) {
          alert(`PHOTO BLOCKED: ${modResult.reason}`);
          setIsUploading(false);
          return;
        }
        setProfile({ ...profile, photoUrl: base64String });
        setIsUploading(false);
        soundManager.play('pda_news');
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#121412] border-l border-[#2a2d2a] overflow-y-auto pb-12 scrollbar-hide">
      <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
      <input type="file" ref={audioInputRef} onChange={handleAudioUpload} accept="audio/mpeg, audio/mp3" className="hidden" />

      <div className="p-4 border-b border-[#2a2d2a] bg-[#1a1c1a]/50 flex justify-between items-center sticky top-0 z-10">
        <h2 className="text-[14px] font-bold text-[#4ade80] tracking-widest">STALKER_DOSSIÊ://{profile.name.toUpperCase()}</h2>
        <div className="flex space-x-2">
          <button onClick={() => setProfile({...profile, language: 'en'})} className={`px-3 py-1 text-[10px] border ${profile.language === 'en' ? 'bg-[#4ade80] text-black' : 'border-[#4ade80]/30 text-[#4ade80]/50'}`}>EN</button>
          <button onClick={() => setProfile({...profile, language: 'pt'})} className={`px-3 py-1 text-[10px] border ${profile.language === 'pt' ? 'bg-[#4ade80] text-black' : 'border-[#4ade80]/30 text-[#4ade80]/50'}`}>PT</button>
        </div>
      </div>

      <div className="p-6 space-y-8">
        <div className="flex flex-col md:flex-row space-y-6 md:space-y-0 md:space-x-8 items-start">
          <div className="relative w-32 h-32 md:w-40 md:h-40 shrink-0 border-2 border-[#2a2d2a] rounded overflow-hidden bg-black group shadow-[0_0_20px_rgba(74,222,128,0.05)]">
             {isUploading && <div className="absolute inset-0 z-10 bg-black/80 flex items-center justify-center"><div className="w-5 h-5 border-2 border-t-transparent border-[#4ade80] rounded-full animate-spin"></div></div>}
             <img src={profile.photoUrl || `https://picsum.photos/seed/${profile.name}/300/300`} alt="Portrait" className="w-full h-full object-cover grayscale opacity-60 group-hover:opacity-100 transition-opacity" />
             <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity" onClick={() => fileInputRef.current?.click()}>
               <span className="text-[9px] font-bold text-[#4ade80] underline">RE-ESCANEAR</span>
             </div>
          </div>

          <div className="flex-1 space-y-4 w-full">
            <div className="space-y-1">
              <label className="text-[8px] font-bold text-[#4ade80]/40 uppercase tracking-[0.2em]">{t.change_name}</label>
              {isEditingName ? (
                <div className="flex items-center space-x-2">
                  <input type="text" value={tempName} onChange={(e) => setTempName(e.target.value)} className="bg-[#0c0d0c] border border-[#4ade80]/50 px-3 py-2 text-sm text-[#4ade80] font-bold w-full focus:outline-none" autoFocus />
                  <button onClick={handleSaveName} className="bg-[#4ade80] text-black px-4 py-2 text-[10px] font-bold uppercase">{t.save}</button>
                </div>
              ) : (
                <div className="flex items-center space-x-4">
                  <h1 className="text-2xl font-black text-[#4ade80] tracking-tight">{profile.name}</h1>
                  <button onClick={() => setIsEditingName(true)} className="text-[9px] font-bold text-[#4ade80]/40 hover:text-[#4ade80] underline transition-colors">{t.edit}</button>
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-[#4ade80]/10 border border-[#4ade80]/20 text-[#4ade80] text-[9px] font-bold rounded uppercase">{profile.rank}</span>
              <span className="px-3 py-1 bg-blue-900/20 border border-blue-500/20 text-blue-400 text-[9px] font-bold rounded uppercase">{profile.experience} XP</span>
              <span className="px-3 py-1 bg-orange-900/20 border border-orange-500/20 text-orange-400 text-[9px] font-bold rounded uppercase">{profile.completedMissions} {t.missions_done}</span>
            </div>
          </div>
        </div>

        <div className="bg-[#1a1c1a]/50 border border-[#2a2d2a] rounded p-6 space-y-6 shadow-lg">
          <div className="flex items-center justify-between border-b border-[#2a2d2a] pb-4">
             <div>
               <h3 className="text-[11px] font-bold text-[#4ade80] uppercase">Módulo de Áudio</h3>
               <p className="text-[9px] text-[#4ade80]/40 italic">Interface acústica do S.O. X-RAY</p>
             </div>
             <button onClick={handleToggleMute} className={`px-4 py-2 text-[10px] font-bold uppercase transition-all border ${isMuted ? 'bg-red-600 text-white border-red-600' : 'bg-[#4ade80] text-black border-[#4ade80]'}`}>
               {isMuted ? 'MUDO: ATIVADO' : 'ÁUDIO: ATIVO'}
             </button>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-[9px] font-bold text-[#4ade80]/60 uppercase tracking-widest">Toque de Mensagem</label>
              {currentMsgSound === 'msg_custom' && (
                <button onClick={() => audioInputRef.current?.click()} className="text-[9px] font-bold text-[#4ade80] underline animate-pulse">
                  {isAudioLoading ? "PROCESSANDO..." : "CARREGAR NOVO MP3"}
                </button>
              )}
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {MSG_SOUNDS.map(s => (
                <button 
                  key={s.id} 
                  onClick={() => handleSoundSelect(s.id)}
                  className={`px-3 py-2 text-[10px] font-bold border rounded transition-all ${currentMsgSound === s.id ? 'bg-[#4ade80]/20 border-[#4ade80] text-[#4ade80]' : 'bg-black border-[#2a2d2a] text-[#4ade80]/40 hover:border-[#4ade80]/30'}`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            {currentMsgSound === 'msg_custom' && !profile.config?.customSound && !isAudioLoading && (
               <div onClick={() => audioInputRef.current?.click()} className="mt-2 p-4 border border-dashed border-[#4ade80]/30 rounded bg-black/40 flex flex-col items-center justify-center cursor-pointer hover:bg-[#4ade80]/5 transition-colors">
                  <span className="text-xl mb-1">📻</span>
                  <span className="text-[9px] font-bold text-[#4ade80]/60 uppercase">Nenhum som carregado. Toque para selecionar MP3.</span>
               </div>
            )}
          </div>
        </div>

        <div className="bg-[#1a1c1a]/30 border border-[#2a2d2a] rounded p-6">
          <h3 className="text-[11px] font-bold text-[#4ade80] uppercase mb-4 tracking-widest">Identidades Anteriores</h3>
          <div className="space-y-3">
            {profile.nameHistory && profile.nameHistory.length > 0 ? (
              profile.nameHistory.map((entry, idx) => (
                <div key={idx} className="flex justify-between items-center text-[10px] font-mono border-b border-[#2a2d2a] pb-2 last:border-0">
                  <span className="text-[#4ade80]/70">{entry.name}</span>
                  <span className="text-[#4ade80]/30 italic">{new Date(entry.timestamp).toLocaleDateString()}</span>
                </div>
              ))
            ) : (
              <p className="text-[10px] text-[#4ade80]/30 font-mono italic">Sem registros de alteração de codinome.</p>
            )}
          </div>
        </div>

        <div className={`p-6 border-l-4 rounded bg-opacity-10 ${factionData.bgColor}`} style={{ borderLeftColor: factionData.color }}>
          <h3 className="text-sm font-bold uppercase tracking-tight mb-2" style={{ color: factionData.color }}>{profile.faction}</h3>
          <p className="text-[12px] text-[#4ade80]/70 leading-relaxed italic">"{factionData.description}"</p>
        </div>
      </div>
    </div>
  );
};
