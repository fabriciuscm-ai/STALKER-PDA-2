
import React, { useState, useEffect } from 'react';
import { StalkerProfile, Faction, Language } from '../types.ts';
import { translations } from '../i18n.ts';
import { OnlineStalker } from '../App.tsx';

interface RankingViewProps {
  language: Language;
  onlineStalkers: OnlineStalker[];
}

export const RankingView: React.FC<RankingViewProps> = ({ language, onlineStalkers }) => {
  const t = translations[language];
  const [displayData, setDisplayData] = useState<Partial<StalkerProfile>[]>([]);

  useEffect(() => {
    // Simula stalkers reais gerando nomes de usuários em vez de NPCs do jogo
    const realUsersPool = [
      { name: 'X_Shadow_X', faction: Faction.MERCENARIES, experience: 4200, rank: 'Veteran' },
      { name: 'Lone_Wolf_99', faction: Faction.LONERS, experience: 3100, rank: 'Experienced' },
      { name: 'ArtifactHunter', faction: Faction.ECOLOGISTS, experience: 2850, rank: 'Experienced' },
      { name: 'Duty_Enforcer', faction: Faction.DUTY, experience: 2400, rank: 'Veteran' },
      { name: 'FreeZone_BR', faction: Faction.FREEDOM, experience: 1950, rank: 'Rookie' },
      { name: 'Stalker_PT_01', faction: Faction.LONERS, experience: 1500, rank: 'Rookie' },
      { name: 'Monolith_Priest', faction: Faction.MONOLITH, experience: 8900, rank: 'Master' },
      { name: 'Bandit_King', faction: Faction.BANDITS, experience: 550, rank: 'Rookie' }
    ];

    // Mapeia stalkers online para parecerem usuários reais
    const active = onlineStalkers.map(s => ({
      name: s.name,
      faction: s.faction,
      experience: Math.floor(Math.random() * 1000) + 100,
      rank: 'Online',
      isOnline: true
    }));
    
    // Ordena por experiência
    const sorted = [...active, ...realUsersPool].sort((a, b) => (b.experience || 0) - (a.experience || 0));
    setDisplayData(sorted);
  }, [onlineStalkers]);

  return (
    <div className="flex flex-col h-full w-full bg-[#121412] overflow-hidden">
      <div className="p-4 border-b border-[#2a2d2a] bg-[#1a1c1a]/50 flex justify-between items-center">
        <h2 className="text-[12px] font-bold text-[#4ade80] uppercase tracking-[0.2em]">{t.ranking}</h2>
        <span className="text-[9px] text-[#4ade80]/30 font-mono text-shadow-glow">BASE_DE_DADOS_USUARIOS</span>
      </div>

      <div className="flex-1 overflow-y-auto p-4 scrollbar-hide">
        <div className="space-y-1">
          {displayData.map((stalker, idx) => {
            const isOnline = (stalker as any).isOnline || onlineStalkers.some(o => o.name === stalker.name);
            return (
              <div key={idx} className={`flex items-center p-3 border border-[#2a2d2a] transition-all hover:bg-[#4ade80]/5 ${isOnline ? 'border-[#4ade80]/30' : 'bg-black/20 opacity-40 grayscale'}`}>
                <div className="w-8 text-[10px] font-mono text-[#4ade80]/40">{idx + 1}.</div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-[12px] font-bold text-[#4ade80]">{stalker.name}</span>
                    {isOnline && <span className="w-1.5 h-1.5 bg-[#4ade80] rounded-full animate-pulse shadow-[0_0_5px_#4ade80]"></span>}
                  </div>
                  <div className="text-[8px] uppercase text-[#4ade80]/40 tracking-widest">{stalker.faction} // {stalker.rank}</div>
                </div>
                <div className="text-right">
                  <div className="text-[11px] font-bold text-[#4ade80]">{stalker.experience?.toLocaleString()}</div>
                  <div className="text-[7px] text-[#4ade80]/30 uppercase font-mono">DATA_XP</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
