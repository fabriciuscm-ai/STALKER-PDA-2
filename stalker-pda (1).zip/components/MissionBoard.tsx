
import React, { useState, useEffect, useRef } from 'react';
import { Mission, StalkerProfile, Faction, Submission } from '../types.ts';
import { FACTION_INFO } from '../constants.tsx';
import { generateMissionFlavor, moderateText, moderateImage } from '../services/geminiService.ts';
import { translations } from '../i18n.ts';
import { toMGRS } from '../utils/coords.ts';

interface MissionBoardProps {
  currentUser: StalkerProfile;
  onAwardXP: (xp: number, factionPoints?: number) => void;
}

export const MissionBoard: React.FC<MissionBoardProps> = ({ currentUser, onAwardXP }) => {
  const t = translations[currentUser.language];
  const [missions, setMissions] = useState<Mission[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [submittingForId, setSubmittingForId] = useState<string | null>(null);
  const [newMission, setNewMission] = useState({ title: '', description: '', location: '', reward: '', xpReward: 100 });
  const [proofData, setProofData] = useState({ text: '', photoUrl: '', coords: '' });
  const [loadingFlavor, setLoadingFlavor] = useState(false);
  const [isModerating, setIsModerating] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSuggestFlavor = async () => {
    if (!newMission.title) return;
    setLoadingFlavor(true);
    const flavor = await generateMissionFlavor(newMission.title, currentUser.faction);
    setNewMission(prev => ({ ...prev, description: flavor || '' }));
    setLoadingFlavor(false);
  };

  const handleCreateMission = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isModerating) return;

    setIsModerating(true);
    const modTitle = await moderateText(newMission.title);
    const modDesc = await moderateText(newMission.description);

    if (!modTitle.safe || !modDesc.safe) {
      alert(`MISSION BLOCKED: Safety violation detected in your proposal.`);
      setIsModerating(false);
      return;
    }

    const mission: Mission = {
      id: Math.random().toString(36).substr(2, 9),
      ...newMission,
      issuer: currentUser,
      status: 'Open',
      timestamp: Date.now()
    };
    setMissions([mission, ...missions]);
    setNewMission({ title: '', description: '', location: '', reward: '', xpReward: 100 });
    setIsCreating(false);
    setIsModerating(false);
  };

  const handleAcceptMission = (id: string) => {
    setMissions(missions.map(m => m.id === id ? { ...m, status: 'In Progress', acceptedBy: currentUser.id } : m));
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        setIsModerating(true);
        const modRes = await moderateImage(base64);
        if (!modRes.safe) {
          alert(`INTEL BLOCKED: ${modRes.reason}`);
          setIsModerating(false);
          return;
        }
        setProofData(prev => ({ ...prev, photoUrl: base64 }));
        setIsModerating(false);
      };
      reader.readAsDataURL(file);
    }
  };

  // Fix: Added missing attachCoords function to retrieve GPS location and format it as MGRS
  const attachCoords = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((pos) => {
        const mgrsString = toMGRS(pos.coords.latitude, pos.coords.longitude);
        setProofData(prev => ({ ...prev, coords: mgrsString }));
      }, (error) => {
        console.error("Geolocation error:", error);
        alert("GPS_SIGNAL_LOST: Unable to retrieve coordinates.");
      }, { enableHighAccuracy: true });
    } else {
      alert("GPS_MODULE_NOT_FOUND");
    }
  };

  const handleSubmitProof = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!submittingForId || isModerating) return;

    setIsModerating(true);
    const modText = await moderateText(proofData.text);
    if (!modText.safe) {
      alert(`INTEL BLOCKED: Description rejected.`);
      setIsModerating(false);
      return;
    }

    const submission: Submission = {
      id: Date.now().toString(),
      stalkerId: currentUser.id,
      stalkerName: currentUser.name,
      proofText: proofData.text,
      proofPhotoUrl: proofData.photoUrl,
      proofCoords: proofData.coords,
      timestamp: Date.now()
    };

    setMissions(missions.map(m => 
      m.id === submittingForId ? { ...m, status: 'Pending Validation', submission } : m
    ));
    setSubmittingForId(null);
    setProofData({ text: '', photoUrl: '', coords: '' });
    setIsModerating(false);
  };

  const issuedMissions = missions.filter(m => m.issuer.id === currentUser.id);
  const availableMissions = missions.filter(m => m.issuer.id !== currentUser.id && m.status === 'Open');

  return (
    <div className="flex flex-col h-full w-full bg-[#121412] border-l border-[#2a2d2a] overflow-hidden">
      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
      
      <div className="p-4 border-b border-[#2a2d2a] bg-[#1a1c1a]/50 flex justify-between items-center">
        <h2 className="text-[14px] font-bold text-[#4ade80]">PDA_NETWORK://TASKS_TERMINAL</h2>
        <button onClick={() => setIsCreating(!isCreating)} className="text-[11px] font-bold px-3 py-1 border border-[#4ade80]/40 text-[#4ade80] hover:bg-[#4ade80]/10 transition-all">
          {isCreating ? t.cancel : t.propose}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-hide">
        {isCreating && (
          <form onSubmit={handleCreateMission} className={`bg-[#1a1c1a] border border-[#4ade80]/30 p-6 rounded-lg space-y-4 animate-in slide-in-from-top duration-300 ${isModerating ? 'opacity-50 pointer-events-none' : ''}`}>
            <h3 className="text-sm font-bold text-[#4ade80] mb-2 uppercase tracking-tighter">{t.propose}</h3>
            {isModerating && <div className="text-[10px] text-[#4ade80] animate-pulse">MODERATING PDA FREQUENCIES...</div>}
            <div className="grid grid-cols-2 gap-2">
                <input type="text" placeholder="Título da Missão" className="bg-[#0c0d0c] border border-[#2a2d2a] p-3 text-xs text-[#4ade80] w-full" value={newMission.title} onChange={(e) => setNewMission({...newMission, title: e.target.value})} required />
                <input type="text" placeholder="Localização" className="bg-[#0c0d0c] border border-[#2a2d2a] p-3 text-xs text-[#4ade80] w-full" value={newMission.location} onChange={(e) => setNewMission({...newMission, location: e.target.value})} required />
            </div>
            <div className="relative">
                <textarea placeholder="Detalhes da tarefa..." className="w-full bg-[#0c0d0c] border border-[#2a2d2a] p-3 text-xs text-[#4ade80] h-24" value={newMission.description} onChange={(e) => setNewMission({...newMission, description: e.target.value})} required />
                <button type="button" onClick={handleSuggestFlavor} disabled={loadingFlavor || !newMission.title} className="absolute bottom-2 right-2 text-[9px] font-bold bg-[#4ade80] text-black px-2 py-1 rounded hover:bg-[#34d399] transition-colors">{loadingFlavor ? 'SYNCING...' : t.suggest}</button>
            </div>
            <div className="grid grid-cols-2 gap-2">
                <input type="text" placeholder="Recompensa (RU/Itens)" className="bg-[#0c0d0c] border border-[#2a2d2a] p-3 text-xs text-[#4ade80]" value={newMission.reward} onChange={(e) => setNewMission({...newMission, reward: e.target.value})} required />
                <input type="number" placeholder="Prêmio de XP" className="bg-[#0c0d0c] border border-[#2a2d2a] p-3 text-xs text-[#4ade80]" value={newMission.xpReward} onChange={(e) => setNewMission({...newMission, xpReward: parseInt(e.target.value)})} required />
            </div>
            <button type="submit" disabled={isModerating} className="w-full bg-[#4ade80] text-[#0c0d0c] font-bold py-3 rounded text-xs hover:bg-[#34d399] transition-all uppercase tracking-widest">Publicar Missão</button>
          </form>
        )}

        {submittingForId && (
          <form onSubmit={handleSubmitProof} className={`bg-[#1a1c1a] border border-blue-500/30 p-6 rounded-lg space-y-4 animate-pulse-slow ${isModerating ? 'opacity-50' : ''}`}>
            <h3 className="text-sm font-bold text-blue-400 mb-2 uppercase tracking-tighter">{t.submit_proof}</h3>
            {isModerating && <div className="text-[10px] text-blue-400 animate-pulse uppercase">Verificando Autenticidade do Intel...</div>}
            <textarea placeholder={t.intel_description} className="w-full bg-[#0c0d0c] border border-blue-500/20 p-3 text-xs text-[#4ade80] h-20" value={proofData.text} onChange={(e) => setProofData({...proofData, text: e.target.value})} required />
            <div className="flex space-x-2">
                <div className="flex-1 flex space-x-2">
                  <button type="button" onClick={() => fileInputRef.current?.click()} className="flex-1 bg-zinc-800 border border-zinc-700 text-zinc-400 text-[10px] font-bold uppercase truncate px-2">
                    {proofData.photoUrl ? "IMAGEM ANEXADA" : "SELECIONAR IMAGEM"}
                  </button>
                  <button type="button" onClick={attachCoords} className="px-3 bg-blue-900/40 border border-blue-500 text-blue-400 text-[10px] font-bold uppercase">{t.attach_coords}</button>
                </div>
            </div>
            {proofData.coords && <div className="text-[10px] font-mono text-blue-400/60">GPS_LOCK: {proofData.coords}</div>}
            <div className="flex space-x-2 pt-2">
                <button type="submit" disabled={isModerating} className="flex-1 bg-blue-600 text-white font-bold py-2 rounded text-[10px] uppercase">Enviar Intel</button>
                <button type="button" onClick={() => setSubmittingForId(null)} className="px-4 border border-zinc-700 text-zinc-500 text-[10px] uppercase">Cancelar</button>
            </div>
          </form>
        )}

        <div className="space-y-4">
          <h4 className="text-[10px] font-bold text-[#4ade80]/40 uppercase tracking-[0.2em] border-b border-[#2a2d2a] pb-1">{t.available_tasks}</h4>
          {availableMissions.length === 0 ? (
            <div className="p-8 border border-[#2a2d2a]/30 bg-[#1a1c1a]/10 rounded-lg text-center opacity-20">
              <p className="text-[10px] font-bold uppercase tracking-widest">Nenhuma missão disponível no setor.</p>
            </div>
          ) : (
            availableMissions.map((mission) => {
              const factionData = FACTION_INFO[mission.issuer.faction];
              return (
                <div key={mission.id} className="border border-[#2a2d2a] bg-[#1a1c1a]/30 p-5 rounded-lg border-l-4 group hover:bg-[#1a1c1a]/50 transition-all" style={{ borderLeftColor: factionData.color }}>
                  <div className="flex justify-between items-start mb-2">
                      <h3 className="text-[15px] font-bold text-[#4ade80]">{mission.title}</h3>
                      <span style={{ color: factionData.color }} className="text-[9px] font-bold uppercase tracking-wider">[{mission.issuer.faction}]</span>
                  </div>
                  <p className="text-[12px] text-[#4ade80]/70 my-2 leading-relaxed">{mission.description}</p>
                  <div className="flex justify-between items-end mt-4">
                      <div className="space-y-1">
                          <div className="text-[10px] text-[#4ade80]/40 uppercase font-mono">RECOMPENSA: {mission.reward}</div>
                          <div className="text-[10px] text-[#4ade80]/40 uppercase font-mono">STALKER: {mission.issuer.name}</div>
                          <div className="text-[10px] text-blue-400 uppercase font-mono tracking-tighter">XP: +{mission.xpReward}</div>
                      </div>
                      <button 
                        onClick={() => handleAcceptMission(mission.id)}
                        className="px-6 py-2 bg-[#4ade80] text-[#0c0d0c] text-[11px] font-bold uppercase hover:bg-[#34d399] transition-all transform active:scale-95"
                      >
                        {t.accept}
                      </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
