
import React, { useState, useEffect } from 'react';
import { Language, Faction } from '../types.ts';
import { translations } from '../i18n.ts';

interface AuthScreenProps {
  onLogin: (faction: Faction) => void;
  language: Language;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin, language }) => {
  const t = translations[language];
  const [step, setStep] = useState<'social' | 'faction'>('social');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [syncCount, setSyncCount] = useState(0);

  useEffect(() => {
    // Check for standalone mode (PWA installed)
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone;
    setIsInstalled(isStandalone);

    // Initial capture from global window object
    if ((window as any).deferredPrompt) {
      setDeferredPrompt((window as any).deferredPrompt);
    }

    const handlePromptEvent = () => {
      if ((window as any).deferredPrompt) {
        setDeferredPrompt((window as any).deferredPrompt);
      }
    };

    window.addEventListener('pwa-prompt-available', handlePromptEvent);
    
    const backupHandler = (e: any) => {
      e.preventDefault();
      (window as any).deferredPrompt = e;
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', backupHandler);

    return () => {
      window.removeEventListener('pwa-prompt-available', handlePromptEvent);
      window.removeEventListener('beforeinstallprompt', backupHandler);
    };
  }, []);

  const handleSyncRequest = () => {
    setSyncCount(prev => prev + 1);
    if ((window as any).deferredPrompt) {
      setDeferredPrompt((window as any).deferredPrompt);
    }
  };

  const handleSocialLogin = () => {
    setStep('faction');
  };

  const handleInstallClick = async () => {
    const promptEvent = deferredPrompt || (window as any).deferredPrompt;
    if (!promptEvent) {
      alert("ERRO_SISTEMA: O navegador ainda não liberou a instalação automática.\n\nSiga o Guia Manual abaixo.");
      return;
    }
    
    promptEvent.prompt();
    const { outcome } = await promptEvent.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
      (window as any).deferredPrompt = null;
      setIsInstalled(true);
    }
  };

  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
  const isInsideInAppBrowser = /FBAN|FBAV|Instagram|LinkedInApp|Discord/.test(navigator.userAgent);
  const activePrompt = deferredPrompt || (window as any).deferredPrompt;

  return (
    <div className="flex flex-col items-center justify-center h-full w-full bg-[#0c0d0c] text-[#4ade80] space-y-8 p-6 text-center animate-flicker relative overflow-y-auto scrollbar-hide">
      <div className="w-24 h-24 border-2 border-[#4ade80] rounded-full flex items-center justify-center animate-pulse shadow-[0_0_30px_rgba(74,222,128,0.2)]">
        <span className="text-4xl pda-icon">☢️</span>
      </div>

      {step === 'social' ? (
        <>
          <div className="space-y-2">
            <h1 className="text-2xl font-bold tracking-widest uppercase">{t.login_title}</h1>
            <p className="text-[10px] opacity-60 font-mono tracking-tighter">{t.login_sub}</p>
          </div>

          <div className="flex flex-col space-y-4 w-full max-w-xs">
            <button 
              onClick={handleSocialLogin}
              className="w-full py-4 bg-[#4ade80]/10 border border-[#4ade80] text-[#4ade80] font-bold text-xs rounded hover:bg-[#4ade80]/20 transition-all flex items-center justify-center space-x-3 group"
            >
              <svg className="w-4 h-4 fill-current group-hover:scale-110 transition-transform pda-icon" viewBox="0 0 24 24">
                <path d="M12.48 10.92v3.28h7.84c-.24 1.84-.908 3.152-1.928 4.176-1.224 1.224-3.136 2.592-7.144 2.592-6.4 0-11.44-5.176-11.44-11.592 0-6.416 5.04-11.592 11.44-11.592 3.496 0 6.12 1.384 8.12 3.272l2.312-2.312c-2.208-2.112-5.112-3.736-10.432-3.736-9.176 0-16.8 7.44-16.8 16.64s7.624 16.64 16.8 16.64c5.04 0 8.768-1.64 11.744-4.704 3.08-3.08 4.056-7.44 4.056-10.96 0-.8-.064-1.536-.216-2.216h-15.584z"/>
              </svg>
              <span>CONTINUAR COM GOOGLE</span>
            </button>

            {/* DOWNLOAD / INSTALL SECTION */}
            {!isInstalled && (
              <div className="mt-8 pt-8 border-t border-[#4ade80]/10 space-y-5">
                <div className="flex justify-between items-center">
                   <h3 className="text-[11px] font-black text-[#4ade80] uppercase tracking-[0.2em]">{t.install_pda}</h3>
                   <button onClick={handleSyncRequest} className="text-[8px] border border-[#4ade80]/20 px-2 py-0.5 rounded hover:bg-[#4ade80]/10 uppercase">Sincronizar</button>
                </div>
                
                {isInsideInAppBrowser && (
                   <div className="p-3 bg-red-900/30 border border-red-500/50 rounded text-[10px] text-red-400 font-bold animate-pulse uppercase leading-tight text-left">
                     ⚠️ ALERTA: NAVEGADOR BLOQUEADO<br/> 
                     <span className="text-[8px] opacity-70 font-normal">O navegador interno de redes sociais não permite instalação. Use Chrome (Android) ou Safari (iPhone).</span>
                   </div>
                )}

                { activePrompt ? (
                  <div className="space-y-3">
                    <button 
                      onClick={handleInstallClick}
                      className="w-full py-5 bg-[#4ade80] text-black font-black text-sm uppercase tracking-widest hover:bg-[#34d399] transition-all shadow-[0_0_30px_rgba(74,222,128,0.5)] animate-pulse border-2 border-white/20"
                    >
                      📥 BAIXAR PDA NO CELULAR
                    </button>
                    <p className="text-[9px] text-[#4ade80]/40 font-mono italic">Isso criará um ícone de aplicativo real no seu aparelho.</p>
                  </div>
                ) : (
                  <div className="p-5 border border-[#4ade80]/30 bg-[#1a1c1a] rounded text-left space-y-4 shadow-2xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-1 bg-[#4ade80]/10 text-[7px] font-bold uppercase tracking-tighter">Extração Manual</div>
                    
                    <div className="flex items-center space-x-3 border-b border-[#4ade80]/10 pb-3">
                       <span className="text-2xl pda-icon">{isIOS ? "🍎" : "🤖"}</span>
                       <div>
                         <p className="text-[10px] text-[#4ade80] font-black uppercase tracking-tighter">
                           {isIOS ? "iOS (Safari)" : "Android (Chrome)"}
                         </p>
                         <p className="text-[8px] text-[#4ade80]/50 uppercase tracking-widest">Procedimento de Hardware</p>
                       </div>
                    </div>

                    <div className="space-y-2 font-mono text-[10px]">
                      <div className="flex items-start space-x-2">
                        <span className="text-[#4ade80] font-bold">01.</span>
                        <p className="text-[#4ade80]/80">Abra no {isIOS ? "Safari" : "Chrome"}.</p>
                      </div>
                      <div className="flex items-start space-x-2">
                        <span className="text-[#4ade80] font-bold">02.</span>
                        <p className="text-[#4ade80]/80">Toque em <span className="text-[#4ade80] font-bold underline pda-icon">{isIOS ? "Compartilhar" : "Menu (⋮)"}</span>.</p>
                      </div>
                      <div className="flex items-start space-x-2">
                        <span className="text-[#4ade80] font-bold">03.</span>
                        <p className="text-[#4ade80]/80">Selecione <span className="text-[#4ade80] font-bold underline">"Adicionar à Tela de Início"</span>.</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
            
            {isInstalled && (
              <div className="mt-4 py-3 px-4 border-2 border-[#4ade80]/40 rounded bg-[#4ade80]/5 flex items-center justify-center space-x-3 text-[#4ade80]">
                <span className="text-xl pda-icon">🛡️</span>
                <div className="text-left">
                  <span className="block text-[10px] font-black uppercase tracking-widest leading-none">PDA_MODO_NATIVO</span>
                  <span className="text-[8px] opacity-60 uppercase font-mono">Executando fora do navegador.</span>
                </div>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="w-full max-w-lg space-y-6">
          <div className="space-y-2">
            <h1 className="text-xl font-bold tracking-widest uppercase">{t.select_faction}</h1>
            <p className="text-[10px] opacity-40 font-mono italic">"A lealdade na Zona é a diferença entre uma bala e um irmão."</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {Object.values(Faction).map((f) => (
              <button
                key={f}
                onClick={() => onLogin(f)}
                className="p-3 text-[10px] font-bold border border-[#4ade80]/20 hover:border-[#4ade80] hover:bg-[#4ade80]/10 transition-all uppercase"
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="mt-12 pt-8 border-t border-[#4ade80]/10 w-full max-w-xs">
        <p className="text-[10px] opacity-30 font-mono text-left">
          MODO: {isInstalled ? 'NATIVO (APP)' : 'WEB (BROWSER)'}<br/>
          HOST: {window.location.hostname}<br/>
          SYNC: {activePrompt ? 'READY' : 'WAITING'}<br/>
          ENCR: AES-256-PDA
        </p>
      </div>
    </div>
  );
};
