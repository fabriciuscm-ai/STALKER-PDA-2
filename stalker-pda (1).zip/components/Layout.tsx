
import React, { useState, useEffect } from 'react';

export const PDAFrame: React.FC<{ children: React.ReactNode, isSoundEnabled?: boolean, isMuted?: boolean }> = ({ children, isSoundEnabled, isMuted }) => {
  const [time, setTime] = useState(new Date());
  const [battery, setBattery] = useState<{ level: number; charging: boolean }>({ level: 100, charging: false });
  const [pdaInfo, setPdaInfo] = useState({ model: 'PDA-S2000', os: 'X-RAY v4.2' });

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 10000);
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((bat: any) => {
        const updateBattery = () => {
          setBattery({
            level: Math.round(bat.level * 100),
            charging: bat.charging
          });
        };
        updateBattery();
        bat.addEventListener('levelchange', updateBattery);
        bat.addEventListener('chargingchange', updateBattery);
      });
    }
    const ua = navigator.userAgent;
    let model = 'PDA-GEN-7';
    if (ua.includes('Android')) model = 'PDA-AND-X1';
    else if (ua.includes('iPhone')) model = 'PDA-IOS-PRO';
    setPdaInfo({ model: model, os: `X-RAY v${ua.length % 10}.0.${Math.floor(Math.random() * 100)}` });
    return () => clearInterval(timer);
  }, []);

  const audioStatus = isMuted ? '🔇 MUDO' : (isSoundEnabled ? '🔊 ATIVO' : '🔇 OFF');

  return (
    <div className="relative w-full h-screen bg-[#0a0a0a] flex items-center justify-center overflow-hidden crt-effect">
      <div className="scanline"></div>
      <div className="relative w-full max-w-5xl h-full md:h-[90vh] md:border-[12px] border-[#1e201e] md:rounded-[40px] shadow-[0_0_50px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col bg-[#111211]">
        <div className="pt-[env(safe-area-inset-top)] h-auto border-b border-[#2a2d2a] flex flex-col bg-[#1a1c1a]">
          <div className="h-10 flex items-center justify-between px-8">
            <div className="flex items-center space-x-4 text-[9px] font-bold tracking-widest text-[#4ade80]/60">
              <span className="hidden sm:inline">{pdaInfo.model} // {pdaInfo.os}</span>
              <span className="sm:hidden">VER: {pdaInfo.os}</span>
              <span className="hidden md:inline">SIGNAL: [|||||]</span>
              <span className={`${isMuted ? 'text-red-500' : 'text-[#4ade80]'} opacity-80 font-black flex items-center space-x-1`}>
                <span className="pda-icon">{isMuted ? '🔇' : (isSoundEnabled ? '🔊' : '🔇')}</span> 
                <span>{isMuted ? 'MUDO' : (isSoundEnabled ? 'ATIVO' : 'OFF')}</span>
              </span>
            </div>
            <div className="flex items-center space-x-3 text-[9px] font-bold text-[#4ade80]/80">
              <span className="animate-pulse text-red-500/70 hidden sm:inline">RAD: 0.02 mSv/h</span>
              <div className="flex items-center space-x-1">
                <span className={`${battery.charging ? 'text-yellow-400' : ''} flex items-center space-x-1`}>
                  {battery.charging && <span className="pda-icon">⚡</span>}
                  <span>BAT: {battery.level}%</span>
                </span>
                <div className="w-4 h-2 border border-[#4ade80]/40 rounded-sm relative overflow-hidden">
                  <div className={`h-full ${battery.level < 20 ? 'bg-red-500' : 'bg-[#4ade80]'}`} style={{ width: `${battery.level}%` }}></div>
                </div>
              </div>
              <span className="border-l border-[#2a2d2a] pl-3">{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
          </div>
        </div>
        <div className="flex-1 flex overflow-hidden">{children}</div>
        <div className="pb-[env(safe-area-inset-bottom)] h-auto bg-[#1a1c1a] border-t border-[#2a2d2a] flex items-center justify-center">
            <div className="w-1/3 h-1.5 my-3 bg-[#2a2d2a] rounded-full"></div>
        </div>
      </div>
    </div>
  );
};

export const SidebarItem: React.FC<{ active: boolean; onClick: () => void; label: string; icon: React.ReactNode }> = ({ active, onClick, label, icon }) => (
  <button onClick={onClick} className={`w-full flex flex-col md:flex-row items-center justify-center md:justify-start space-y-1 md:space-y-0 md:space-x-3 px-2 md:px-6 py-4 transition-all border-l-4 ${active ? 'border-[#4ade80] bg-[#4ade80]/10 text-[#4ade80]' : 'border-transparent text-[#4ade80]/40 hover:text-[#4ade80]/70 hover:bg-[#4ade80]/5'}`}>
    <span className="text-xl flex items-center justify-center">{icon}</span>
    <span className="font-bold uppercase text-[9px] md:text-[12px] tracking-tighter text-center md:text-left">{label}</span>
  </button>
);
