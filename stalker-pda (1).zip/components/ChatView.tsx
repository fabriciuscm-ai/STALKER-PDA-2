
import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, StalkerProfile, Faction } from '../types.ts';
import { FACTION_INFO } from '../constants.tsx';
import { moderateText } from '../services/geminiService.ts';
import { translations } from '../i18n.ts';
import { OnlineStalker } from '../App.tsx';
import { soundManager } from '../services/soundService.ts';

interface ChatViewProps {
  currentUser: StalkerProfile;
  onlineStalkers: OnlineStalker[];
}

export const ChatView: React.FC<ChatViewProps> = ({ currentUser, onlineStalkers }) => {
  const t = translations[currentUser.language];
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isModerating, setIsModerating] = useState(false);
  const [activeChannel, setActiveChannel] = useState<'Global' | 'Faction'>('Global');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
    if (messages.length > 0) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg.sender.id !== currentUser.id) {
        const preferredSound = currentUser.config?.msgSound || 'msg_classic';
        if (preferredSound === 'msg_custom' && currentUser.config?.customSound) {
          soundManager.playCustom(currentUser.config.customSound);
        } else {
          soundManager.play(preferredSound);
        }
      }
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isModerating) return;
    setIsModerating(true);
    const modResult = await moderateText(input);
    if (!modResult.safe) {
      alert(`${t.content_blocked}: ${modResult.reason}`);
      setIsModerating(false);
      return;
    }
    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      sender: currentUser,
      text: input,
      timestamp: Date.now(),
      type: activeChannel
    };
    setMessages([...messages, newMessage]);
    setInput('');
    setIsModerating(false);
    soundManager.play('pda_click');
  };

  const filteredMessages = messages.filter(msg => {
    if (activeChannel === 'Global') return msg.type === 'Global';
    return msg.type === 'Faction' && msg.sender.faction === currentUser.faction;
  });

  return (
    <div className="flex flex-col h-full w-full bg-[#121412]">
      <div className="border-b border-[#2a2d2a] bg-[#1a1c1a]/80">
        <div className="p-4 flex justify-between items-center">
          <h2 className="text-[11px] font-black text-[#4ade80] uppercase tracking-widest">
            {activeChannel === 'Global' ? 'CANAL_GLOBAL' : `CANAL_${currentUser.faction.toUpperCase()}`}
          </h2>
          <div className="flex items-center space-x-2">
             <span className="w-1.5 h-1.5 bg-[#4ade80] rounded-full animate-pulse"></span>
             <span className="text-[8px] text-[#4ade80]/60 font-mono uppercase">{onlineStalkers.length + 1} SINAIS_ATIVOS</span>
          </div>
        </div>
        <div className="flex px-4 space-x-2">
          {['Global', 'Faction'].map(type => (
            <button key={type} onClick={() => { setActiveChannel(type as any); soundManager.play('pda_click'); }} className={`px-4 py-2 text-[10px] font-bold transition-all border-b-2 ${activeChannel === type ? 'border-[#4ade80] text-[#4ade80] bg-[#4ade80]/5' : 'border-transparent text-[#4ade80]/30 hover:text-[#4ade80]/60'}`}>
              {type === 'Global' ? 'COMUNIDADE' : currentUser.faction.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
        {filteredMessages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center opacity-20 text-center p-8">
            <span className="text-3xl mb-2 pda-icon">📡</span>
            <p className="text-[10px] font-bold uppercase tracking-widest">Nenhuma transmissão detectada nesta frequência.</p>
          </div>
        ) : (
          filteredMessages.map((msg) => {
            const isMe = msg.sender.id === currentUser.id;
            const isOnline = isMe || onlineStalkers.some(s => s.name === msg.sender.name);
            const color = FACTION_INFO[msg.sender.faction]?.color || '#4ade80';
            
            return (
              <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} ${!isOnline ? 'opacity-40 grayscale' : ''}`}>
                <div className="flex items-center space-x-2 mb-1 px-1">
                  <span style={{ color }} className="text-[8px] font-bold uppercase tracking-tighter">[{msg.sender.faction}]</span>
                  <span className="text-[10px] font-bold text-[#4ade80]">{msg.sender.name}</span>
                  {!isOnline && <span className="text-[7px] text-red-500 font-bold">[SINAL_PERDIDO]</span>}
                </div>
                <div className={`max-w-[90%] p-3 rounded border text-[12px] leading-relaxed ${isMe ? 'bg-[#4ade80]/10 border-[#4ade80]/30 text-[#4ade80]' : 'bg-[#1a1c1a] border-[#2a2d2a] text-[#4ade80]/80'}`}>
                  {msg.text}
                </div>
              </div>
            );
          })
        )}
      </div>

      <form onSubmit={handleSendMessage} className="p-4 bg-[#1a1c1a] border-t border-[#2a2d2a]">
        <div className="relative flex items-center">
          <input type="text" value={input} disabled={isModerating} onChange={(e) => setInput(e.target.value)} placeholder={isModerating ? "PROCESSANDO..." : "Transmitir para a Zona..."} className="w-full bg-[#0c0d0c] border border-[#2a2d2a] rounded-lg px-4 py-3 text-[12px] text-[#4ade80] focus:border-[#4ade80]/40 focus:outline-none placeholder-[#4ade80]/20" />
          <button type="submit" disabled={isModerating} className="absolute right-2 px-3 py-1.5 bg-[#4ade80] text-black font-bold text-[10px] rounded hover:bg-[#34d399] transition-all uppercase disabled:opacity-30">
            {isModerating ? '...' : 'Enviar'}
          </button>
        </div>
      </form>
    </div>
  );
};
