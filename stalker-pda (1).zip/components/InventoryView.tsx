
import React, { useState } from 'react';
import { Artifact, StalkerProfile } from '../types.ts';
import { translations } from '../i18n.ts';
import { OnlineStalker } from '../App.tsx';
import { soundManager } from '../services/soundService.ts';

interface InventoryViewProps {
  profile: StalkerProfile;
  onSell: (xp: number) => void;
  onRemove: (id: string) => void;
  onlineStalkers: OnlineStalker[];
}

const RARITY_COLORS = {
  Common: 'border-[#4ade80]/40 text-[#4ade80]/60',
  Uncommon: 'border-[#4ade80]/60 text-[#4ade80]/80',
  Rare: 'border-[#4ade80]/80 text-[#4ade80]',
  Legendary: 'border-[#4ade80] text-[#4ade80] shadow-[0_0_15px_rgba(74,222,128,0.3)]'
};

const MAX_SLOTS = 15;

export const InventoryView: React.FC<InventoryViewProps> = ({ profile, onSell, onRemove, onlineStalkers }) => {
  const t = translations[profile.language];
  const [selectedArtifact, setSelectedArtifact] = useState<Artifact | null>(null);
  const [isTrading, setIsTrading] = useState(false);
  const [targetStalker, setTargetStalker] = useState<string>('');

  const handleSell = (art: Artifact) => {
    onSell(art.xpValue);
    onRemove(art.id);
    setSelectedArtifact(null);
    soundManager.play('pda_news');
  };

  const handleTransfer = () => {
    if (!selectedArtifact || !targetStalker) return;
    const stalkerName = onlineStalkers.find(s => s.id === targetStalker)?.name || 'Unknown Stalker';
    
    alert(`TRANSMISSÃO_INICIADA: Item [${selectedArtifact.name}] enviado para ${stalkerName}.`);
    onRemove(selectedArtifact.id);
    setSelectedArtifact(null);
    setIsTrading(false);
    soundManager.play('pda_news');
  };

  const slots = Array.from({ length: MAX_SLOTS }, (_, i) => profile.inventory[i] || null);

  return (
    <div className="flex flex-col h-full w-full bg-[#121412] border-l border-[#2a2d2a] overflow-hidden">
      <div className="p-4 border-b border-[#2a2d2a] bg-[#1a1c1a]/50 flex justify-between items-center">
        <h2 className="text-[14px] font-bold text-[#4ade80] uppercase tracking-widest">Módulo de Contenção e Suprimentos</h2>
        <span className="text-[10px] text-[#4ade80]/30 font-mono">OCUPAÇÃO: {profile.inventory.length}/{MAX_SLOTS}</span>
      </div>

      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        <div className="flex-1 overflow-y-auto p-4 scrollbar-hide bg-[#0c0d0c]/30">
          <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 gap-2">
            {slots.map((art, index) => (
              art ? (
                <button 
                  key={art.id} 
                  onClick={() => { setSelectedArtifact(art); setIsTrading(false); soundManager.play('pda_click'); }}
                  className={`aspect-square relative flex flex-col items-center justify-center bg-black/60 border-2 rounded-lg p-2 text-center transition-all transform active:scale-95 group overflow-hidden ${RARITY_COLORS[art.rarity] || 'border-[#4ade80]/30'} ${selectedArtifact?.id === art.id ? 'bg-[#4ade80]/20 border-[#4ade80] shadow-[0_0_10px_rgba(74,222,128,0.2)]' : ''}`}
                >
                  <div className="text-xl sm:text-2xl mb-1 pda-icon">{art.icon}</div>
                  <div className="text-[8px] sm:text-[9px] font-bold uppercase truncate w-full text-[#4ade80]">{art.name}</div>
                  <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </button>
              ) : (
                <div 
                  key={`empty-${index}`} 
                  className="aspect-square border-2 border-[#4ade80]/20 bg-black/10 rounded-lg flex items-center justify-center transition-colors hover:border-[#4ade80]/30"
                >
                  <div className="w-1.5 h-1.5 bg-[#4ade80]/10 rounded-full"></div>
                </div>
              )
            ))}
          </div>
          {profile.inventory.length === 0 && (
            <div className="mt-8 flex flex-col items-center justify-center opacity-20">
               <span className="text-4xl mb-4 pda-icon">🎒</span>
               <p className="text-[10px] font-bold uppercase text-[#4ade80]">{t.no_artifacts}</p>
            </div>
          )}
        </div>

        <div className="w-full md:w-80 bg-[#1a1c1a] border-t md:border-t-0 md:border-l border-[#2a2d2a] p-6 overflow-y-auto">
          {selectedArtifact ? (
            <div className="space-y-6 animate-in fade-in duration-300 text-[#4ade80]">
               <div className="text-center">
                  <div className="text-6xl mb-4 pda-icon">{selectedArtifact.icon}</div>
                  <h3 className="text-xl font-black uppercase tracking-tighter">{selectedArtifact.name}</h3>
                  <span className={`text-[10px] font-bold uppercase tracking-[0.3em] ${RARITY_COLORS[selectedArtifact.rarity]}`}>{selectedArtifact.rarity}</span>
               </div>

               <div className="p-4 bg-black/30 border border-[#2a2d2a] rounded">
                 <p className="text-xs italic opacity-60 leading-relaxed">"{selectedArtifact.description}"</p>
               </div>

               <div className="space-y-3 pt-4 border-t border-[#2a2d2a]">
                  <div className="flex justify-between items-center text-[10px] font-mono mb-4">
                    <span className="opacity-40 uppercase">Sincronia de Dados:</span>
                    <span className="font-bold">+{selectedArtifact.xpValue} XP</span>
                  </div>

                  {!isTrading ? (
                    <>
                      <button 
                        onClick={() => handleSell(selectedArtifact)}
                        className="w-full py-3 bg-[#4ade80] text-black font-bold text-xs uppercase hover:bg-white transition-all shadow-[0_0_15px_rgba(74,222,128,0.2)]"
                      >
                        CONSUMIR / TRANSMITIR
                      </button>
                      <button 
                        onClick={() => setIsTrading(true)}
                        className="w-full py-3 border border-[#4ade80]/40 text-[#4ade80] font-bold text-xs uppercase hover:bg-[#4ade80]/10 transition-all"
                      >
                        {t.transfer}
                      </button>
                    </>
                  ) : (
                    <div className="space-y-4 animate-in slide-in-from-bottom-2 duration-200">
                       <label className="text-[9px] font-bold uppercase tracking-widest opacity-60">Selecionar Receptor</label>
                       <select 
                         value={targetStalker} 
                         onChange={(e) => setTargetStalker(e.target.value)}
                         className="w-full bg-black border border-[#4ade80]/30 p-2 text-[10px] text-[#4ade80] focus:outline-none"
                       >
                         <option value="">-- STALKERS_NA_MALHA --</option>
                         {onlineStalkers.map(s => (
                           <option key={s.id} value={s.id}>{s.name.toUpperCase()} [{s.faction}]</option>
                         ))}
                       </select>
                       <div className="flex space-x-2">
                         <button onClick={handleTransfer} disabled={!targetStalker} className="flex-1 py-3 bg-[#4ade80] text-black font-bold text-[10px] uppercase disabled:opacity-30">Transferir</button>
                         <button onClick={() => setIsTrading(false)} className="px-4 border border-[#4ade80]/20 text-[#4ade80]/60 text-[10px] uppercase">Sair</button>
                       </div>
                    </div>
                  )}
               </div>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center opacity-20 text-center">
              <p className="text-[10px] font-bold uppercase tracking-widest text-[#4ade80]">Selecione um item para análise ou troca</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
