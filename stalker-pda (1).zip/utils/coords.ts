
/**
 * Simplified MGRS-style formatter for S.T.A.L.K.E.R. immersion.
 * Real MGRS is very complex; this provides the visual aesthetic 
 * using Grid Zone Designators and numerical coordinates.
 */
export function toMGRS(lat: number, lng: number): string {
  // GZD: Latitude bands and Longitude zones
  const zone = Math.floor((lng + 180) / 6) + 1;
  const bands = 'CDEFGHJKLMNPQRSTUVWXX'; // Simplified bands
  const band = bands[Math.floor((lat + 80) / 8)];

  // Convert decimal to "Easting/Northing" style integers
  const easting = Math.floor(((lng + 180) % 6) * 16666).toString().padStart(5, '0');
  const northing = Math.floor(((lat + 90) % 8) * 12500).toString().padStart(5, '0');

  // Format: 33U XP 05004 40001 (simplified)
  // We'll use a constant "XP" or similar for the 100km square ID for flavor
  return `${zone}${band} XP ${easting.slice(0, 5)} ${northing.slice(0, 5)}`;
}

export function generateRandomStalkerLocation(lat: number, lng: number, radiusKm: number) {
  const r = radiusKm / 111.3; // Approx km to deg
  const u = Math.random();
  const v = Math.random();
  const w = r * Math.sqrt(u);
  const t = 2 * Math.PI * v;
  const x = w * Math.cos(t);
  const y = w * Math.sin(t);
  return {
    lat: lat + y,
    lng: lng + x
  };
}
