
export enum Faction {
  LONERS = 'Loners',
  DUTY = 'Duty',
  FREEDOM = 'Freedom',
  MERCENARIES = 'Mercenaries',
  ECOLOGISTS = 'Ecologists',
  BANDITS = 'Bandits',
  RENEGADES = 'Renegades',
  SIN = 'Sin',
  UNISG = 'UNISG',
  MONOLITH = 'Monolith',
  MILITARY = 'Military'
}

export type Language = 'pt' | 'en';

export interface NameHistoryEntry {
  name: string;
  timestamp: number;
}

export type ArtifactRarity = 'Common' | 'Uncommon' | 'Rare' | 'Legendary';

export interface Artifact {
  id: string;
  name: string;
  rarity: ArtifactRarity;
  xpValue: number;
  description: string;
  icon: string;
  isArtifact?: boolean;
}

export interface ArtifactSpawn {
  id: string;
  artifact: Artifact;
  lat: number;
  lng: number;
  timestamp: number;
}

export interface StalkerProfile {
  id: string;
  name: string;
  faction: Faction;
  rank: string;
  experience: number;
  completedMissions: number;
  photoUrl?: string;
  language: Language;
  reputationMap: Record<Faction, number>;
  rankPosition?: number;
  isOnline?: boolean;
  lastSeen?: number;
  nameHistory: NameHistoryEntry[];
  inventory: Artifact[];
  config?: {
    msgSound: string;
    customSound?: string;
    isMuted: boolean;
  };
}

export interface Submission {
  id: string;
  stalkerId: string;
  stalkerName: string;
  proofText?: string;
  proofPhotoUrl?: string;
  proofCoords?: string;
  timestamp: number;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  issuer: StalkerProfile;
  location: string;
  reward: string;
  xpReward: number;
  factionRequirement?: Faction;
  status: 'Open' | 'In Progress' | 'Pending Validation' | 'Completed' | 'Failed';
  timestamp: number;
  acceptedBy?: string;
  submission?: Submission;
}

export interface ChatMessage {
  id: string;
  sender: StalkerProfile;
  text: string;
  timestamp: number;
  type: 'Global' | 'Faction' | 'System';
}
