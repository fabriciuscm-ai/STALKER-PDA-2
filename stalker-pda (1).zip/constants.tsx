
import { Faction } from './types';

export const FACTION_INFO: Record<Faction, { color: string; bgColor: string; description: string }> = {
  [Faction.LONERS]: { 
    color: '#fbbf24', 
    bgColor: 'bg-amber-900/30',
    description: 'Free explorers of the Zone. They seek artifacts and profit, avoiding politics.'
  },
  [Faction.DUTY]: { 
    color: '#ef4444', 
    bgColor: 'bg-red-900/30',
    description: 'A paramilitary group dedicated to protecting the world from the Zone\'s spread.'
  },
  [Faction.FREEDOM]: { 
    color: '#22c55e', 
    bgColor: 'bg-green-900/30',
    description: 'Anarchists who believe the Zone is a gift to humanity and should be shared.'
  },
  [Faction.MERCENARIES]: { 
    color: '#3b82f6', 
    bgColor: 'bg-blue-900/30',
    description: 'Highly trained professionals working for the highest bidder. Secretive and dangerous.'
  },
  [Faction.ECOLOGISTS]: { 
    color: '#f97316', 
    bgColor: 'bg-orange-900/30',
    description: 'Scientists studying the Zone to harness its anomalies for the benefit of science.'
  },
  [Faction.BANDITS]: { 
    color: '#71717a', 
    bgColor: 'bg-zinc-800/50',
    description: 'The criminal underworld of the Zone. Robbing, extorting, and surviving.'
  },
  [Faction.RENEGADES]: { 
    color: '#b45309', 
    bgColor: 'bg-amber-950/50',
    description: 'The outcasts among outcasts. Desperate survivors with nothing to lose.'
  },
  [Faction.SIN]: { 
    color: '#7f1d1d', 
    bgColor: 'bg-red-950/70',
    description: 'A dark cult that believes the Zone is a divine punishment.'
  },
  [Faction.UNISG]: { 
    color: '#0ea5e9', 
    bgColor: 'bg-sky-950/50',
    description: 'International scientific and military observers with hidden agendas.'
  },
  [Faction.MONOLITH]: { 
    color: '#f8fafc', 
    bgColor: 'bg-slate-800/70',
    description: 'Fanatical guardians of the Zone\'s center. They worship the C-Consciousness.'
  },
  [Faction.MILITARY]: { 
    color: '#4d7c0f', 
    bgColor: 'bg-lime-900/40',
    description: 'Ukrainian army forces trying to maintain the quarantine and eliminate intruders.'
  }
};
