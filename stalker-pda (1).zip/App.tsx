
import React, { useState, useEffect, useCallback } from 'react';
import { PDAFrame, SidebarItem } from './components/Layout.tsx';
import { ChatView } from './components/ChatView.tsx';
import { MissionBoard } from './components/MissionBoard.tsx';
import { ProfileView } from './components/ProfileView.tsx';
import { MapView } from './components/MapView.tsx';
import { RankingView } from './components/RankingView.tsx';
import { AuthScreen } from './components/AuthScreen.tsx';
import { InventoryView } from './components/InventoryView.tsx';
import { DetectorView } from './components/DetectorView.tsx';
import { StalkerProfile, Faction, Artifact, ArtifactSpawn } from './types.ts';
import { translations } from './i18n.ts';
import { generateRandomStalkerLocation } from './utils/coords.ts';
import { soundManager } from './services/soundService.ts';

type ActiveTab = 'chat' | 'missions' | 'map' | 'profile' | 'ranking' | 'inventory' | 'detector';

export interface OnlineStalker extends Partial<StalkerProfile> {
  id: string;
  name: string;
  faction: Faction;
  lat: number;
  lng: number;
  signalStrength: number;
  isOnline: boolean;
}

const ARTIFACT_POOL_LIST = [
  { name: 'Jellyfish', xpValue: 150, description: 'Forms in gravitational anomalies. Emits a weak protective field.', icon: '⭕', rarity: 'Common' as const, isArtifact: true },
  { name: 'Stone Flower', xpValue: 200, description: 'Created in extreme pressure zones. Hard as diamond.', icon: '◈', rarity: 'Common' as const, isArtifact: true },
  { name: 'Flash', xpValue: 400, description: 'Stores electrical energy. Highly volatile.', icon: '⚡', rarity: 'Uncommon' as const, isArtifact: true },
  { name: 'Nightstar', xpValue: 1200, description: 'Glows softly in the dark. Highly prized.', icon: '✦', rarity: 'Rare' as const, isArtifact: true },
  { name: 'Goldfish', xpValue: 1500, description: 'Extremely heavy for its size.', icon: '⌬', rarity: 'Rare' as const, isArtifact: true },
  { name: 'Compass', xpValue: 4500, description: 'Allows navigation through spatial bubbles.', icon: '⊕', rarity: 'Legendary' as const, isArtifact: true }
];

const UTILITY_ITEMS_POOL = [
  { name: 'Medkit', xpValue: 35, description: 'Standard issue medical kit. Contains bandages, painkillers, and stimulants.', icon: '💉', rarity: 'Common' as const, isArtifact: false },
  { name: 'Bandage', xpValue: 15, description: 'Sterile bandage to stop bleeding.', icon: '🩹', rarity: 'Common' as const, isArtifact: false },
  { name: 'Anti-rad', xpValue: 50, description: 'Effective radiation treatment. Essential for deep Zone exploration.', icon: '💊', rarity: 'Uncommon' as const, isArtifact: false },
  { name: 'Vodka "Cossacks"', xpValue: 20, description: 'Traditional remedy against radiation and fear.', icon: '🍾', rarity: 'Common' as const, isArtifact: false },
  { name: 'Tourist\'s Delight', xpValue: 25, description: 'Canned meat of questionable origin. Smells okay.', icon: '🥫', rarity: 'Common' as const, isArtifact: false },
  { name: 'Diet Sausage', xpValue: 20, description: 'A favorite among stalkers. Tastes like chicken?', icon: '🌭', rarity: 'Common' as const, isArtifact: false },
  { name: 'Bread', xpValue: 10, description: 'A bit dry, but filling.', icon: '🍞', rarity: 'Common' as const, isArtifact: false },
  { name: 'Energy Drink', xpValue: 30, description: 'Non-stop energy for long runs through the Zone.', icon: '🥤', rarity: 'Common' as const, isArtifact: false },
  { name: 'Mineral Water', xpValue: 15, description: 'Clean water from outside the Zone. Vital for hydration.', icon: '💧', rarity: 'Common' as const, isArtifact: false }
];

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState<ActiveTab>('map');
  const [isEmission, setIsEmission] = useState(false);
  const [onlineStalkers, setOnlineStalkers] = useState<OnlineStalker[]>([]);
  const [systemLogs, setSystemLogs] = useState<string[]>(["SISTEMA_INICIADO", "BUSCANDO_SATELITES..."]);
  const [isSoundEnabled, setIsSoundEnabled] = useState(true);
  const [activeArtifacts, setActiveArtifacts] = useState<ArtifactSpawn[]>([]);
  const [userCoords, setUserCoords] = useState<{ lat: number, lng: number } | null>(null);
  
  const [profile, setProfile] = useState<StalkerProfile>({
    id: 'user_pda_01',
    name: 'Newcomer',
    faction: Faction.LONERS,
    rank: 'Rookie',
    experience: 0,
    completedMissions: 0,
    language: 'pt',
    nameHistory: [],
    inventory: [],
    reputationMap: {
      [Faction.LONERS]: 100,
      [Faction.DUTY]: 0,
      [Faction.FREEDOM]: 0,
      [Faction.MERCENARIES]: 0,
      [Faction.ECOLOGISTS]: 0,
      [Faction.BANDITS]: 0,
      [Faction.RENEGADES]: 0,
      [Faction.SIN]: 0,
      [Faction.UNISG]: 0,
      [Faction.MONOLITH]: 0,
      [Faction.MILITARY]: 0,
    },
    config: {
      msgSound: 'msg_classic',
      isMuted: false
    }
  });

  const t = translations[profile.language];

  useEffect(() => {
    soundManager.setEnabled(isSoundEnabled);
  }, [isSoundEnabled]);

  const addLog = (msg: string) => {
    setSystemLogs(prev => [msg, ...prev].slice(0, 5));
  };

  const handleTabChange = (tab: ActiveTab) => {
    setActiveTab(tab);
    soundManager.play('pda_click');
  };

  const syncNetwork = useCallback((lat: number, lng: number) => {
    const realUserNames = [
      'Stalker_Ghost', 'Zone_Runner', 'Anomalous_Boi', 'ShadowMaster', 
      'Rookie_Killer', 'Artifact_Pro', 'Lost_Stalker_PT', 'Dark_Seeker', 
      'Chernobyl_Child', 'Psy_Warrior', 'BoltsAndAnomalies', 'Radiated_Soul'
    ];
    const factions = Object.values(Faction);
    
    setOnlineStalkers(prev => {
      const newCount = Math.floor(Math.random() * 5) + 3;
      const newStalkers = Array.from({ length: newCount }).map((_, i) => ({
        id: `user_${i}_${Date.now()}`,
        name: realUserNames[Math.floor(Math.random() * realUserNames.length)] + `_${Math.floor(Math.random() * 99)}`,
        faction: factions[Math.floor(Math.random() * factions.length)],
        signalStrength: Math.floor(Math.random() * 40) + 60,
        isOnline: true,
        ...generateRandomStalkerLocation(lat, lng, 1.2)
      }));

      addLog(`REDE: ${newCount} USUÁRIOS IDENTIFICADOS`);
      if (isLoggedIn) soundManager.play('pda_news');
      return newStalkers;
    });
  }, [isLoggedIn]);

  const spawnWorldItem = useCallback((lat: number, lng: number) => {
    const roll = Math.random();
    let itemData;
    let logMsg = "";

    if (roll < 0.45) {
      itemData = UTILITY_ITEMS_POOL[Math.floor(Math.random() * UTILITY_ITEMS_POOL.length)];
      logMsg = `REDE: SINAL DE SUPRIMENTOS PERDIDOS DETECTADO`;
    } 
    else if (roll < 0.50) {
      itemData = ARTIFACT_POOL_LIST[Math.floor(Math.random() * ARTIFACT_POOL_LIST.length)];
      logMsg = `DADO_ANÔMALO: PICO DE ENERGIA DETECTADO`;
    } 
    else {
      return;
    }

    const offsetLat = (Math.random() - 0.5) * 0.0012; 
    const offsetLng = (Math.random() - 0.5) * 0.0012;
    
    const newSpawn: ArtifactSpawn = {
      id: `item_${Date.now()}`,
      artifact: { ...itemData, id: `item_ref_${Date.now()}` },
      lat: lat + offsetLat,
      lng: lng + offsetLng,
      timestamp: Date.now()
    };

    setActiveArtifacts(prev => [...prev, newSpawn].slice(-20)); 
    addLog(logMsg);
  }, []);

  const handleLogin = (chosenFaction: Faction) => {
    setProfile(prev => ({
      ...prev,
      faction: chosenFaction,
      reputationMap: { ...prev.reputationMap, [chosenFaction]: 200 }
    }));
    setIsLoggedIn(true);
    soundManager.play('pda_startup');
    addLog(`LOGIN_USUARIO: ${chosenFaction.toUpperCase()} VERIFICADO`);
  };

  const awardPoints = (xp: number, factionPoints: number = 0) => {
    setProfile(prev => {
      const newRepMap = { ...prev.reputationMap };
      newRepMap[prev.faction] = (newRepMap[prev.faction] || 0) + factionPoints;
      
      let newRank = prev.rank;
      const totalXp = prev.experience + xp;
      if (totalXp > 5000) newRank = 'Legend';
      else if (totalXp > 2500) newRank = 'Master';
      else if (totalXp > 1000) newRank = 'Veteran';
      else if (totalXp > 500) newRank = 'Experienced';

      addLog(`XP_GANHO: +${xp}`);
      soundManager.play('pda_news');
      return {
        ...prev,
        experience: totalXp,
        rank: newRank,
        reputationMap: newRepMap,
        completedMissions: xp > 25 ? prev.completedMissions + 1 : prev.completedMissions
      };
    });
  };

  const addArtifact = (art: Artifact) => {
    setProfile(prev => ({
      ...prev,
      inventory: [...prev.inventory, art].slice(0, 15)
    }));
    addLog(`ITEM_ADQUIRIDO: ${art.name.toUpperCase()}`);
    soundManager.play('pda_news');
  };

  const collectArtifact = (spawnId: string) => {
    const spawn = activeArtifacts.find(s => s.id === spawnId);
    if (spawn) {
      addArtifact(spawn.artifact);
      awardPoints(spawn.artifact.xpValue);
      setActiveArtifacts(prev => prev.filter(s => s.id !== spawnId));
      addLog(`COLETA_SUCESSO: ${spawn.artifact.name.toUpperCase()}`);
    }
  };

  const removeArtifact = (id: string) => {
    setProfile(prev => ({
      ...prev,
      inventory: prev.inventory.filter(a => a.id !== id)
    }));
  };

  useEffect(() => {
    const checkStatus = async () => {
      if (!("geolocation" in navigator)) return;
      
      navigator.geolocation.getCurrentPosition(async (pos) => {
        const { latitude, longitude } = pos.coords;
        setUserCoords({ lat: latitude, lng: longitude });
        syncNetwork(latitude, longitude);
        spawnWorldItem(latitude, longitude);

        try {
          const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=weather_code,rain`);
          const data = await res.json();
          const isBadWeather = data.current.rain > 0 || data.current.weather_code >= 51;
          
          if (isBadWeather && !isEmission) {
            addLog("ALERTA: EMISSÃO DETECTADA");
            soundManager.play('pda_alarm', true);
          } else if (!isBadWeather && isEmission) {
            soundManager.stop('pda_alarm');
          }
          setIsEmission(isBadWeather);
        } catch (e) {
          console.error("Weather check failed", e);
        }
      });
    };

    checkStatus();
    const interval = setInterval(checkStatus, 45000); 
    return () => clearInterval(interval);
  }, [syncNetwork, isEmission, spawnWorldItem]);

  if (!isLoggedIn) {
    return (
      <PDAFrame isSoundEnabled={isSoundEnabled}>
        <AuthScreen onLogin={handleLogin} language={profile.language} />
      </PDAFrame>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'chat':
        return <ChatView currentUser={profile} onlineStalkers={onlineStalkers} />;
      case 'missions':
        return <MissionBoard currentUser={profile} onAwardXP={awardPoints} />;
      case 'map':
        return <MapView language={profile.language} isEmission={isEmission} onAction={awardPoints} onArtifactFound={addArtifact} onlineStalkers={onlineStalkers} artifactsInWorld={activeArtifacts} onCollectItem={collectArtifact} />;
      case 'profile':
        return <ProfileView profile={profile} setProfile={setProfile} isSoundEnabled={isSoundEnabled} setIsSoundEnabled={setIsSoundEnabled} />;
      case 'ranking':
        return <RankingView language={profile.language} onlineStalkers={onlineStalkers} />;
      case 'inventory':
        return <InventoryView profile={profile} onSell={awardPoints} onRemove={removeArtifact} onlineStalkers={onlineStalkers} />;
      case 'detector':
        return <DetectorView language={profile.language} userCoords={userCoords} activeArtifacts={activeArtifacts} onCollect={collectArtifact} />;
      default:
        return <MapView language={profile.language} isEmission={isEmission} onAction={awardPoints} onArtifactFound={addArtifact} onlineStalkers={onlineStalkers} artifactsInWorld={activeArtifacts} onCollectItem={collectArtifact} />;
    }
  };

  return (
    <PDAFrame isSoundEnabled={isSoundEnabled} isMuted={profile.config?.isMuted}>
      {isEmission && (
        <div className="absolute inset-0 z-[9999] pointer-events-none border-4 border-red-600/40 animate-pulse bg-red-900/10 flex items-center justify-center">
           <div className="bg-red-600 text-white font-black text-2xl md:text-4xl px-8 py-4 rotate-[-5deg] border-4 border-white shadow-[0_0_50px_rgba(255,0,0,1)] text-center">
             EMISSÃO DETECTADA!<br/><span className="text-xl pda-icon">☣️</span><br/><span className="text-xl">PROCURE ABRIGO</span>
           </div>
        </div>
      )}

      <div className="w-20 md:w-64 bg-[#1a1c1a] border-r border-[#2a2d2a] flex flex-col h-full">
        <div className="py-6 flex-1 overflow-y-auto scrollbar-hide">
          <SidebarItem active={activeTab === 'map'} onClick={() => handleTabChange('map')} label={t.map} icon={<span className="pda-icon text-xl">🗺️</span>} />
          <SidebarItem active={activeTab === 'detector'} onClick={() => handleTabChange('detector')} label={t.detector} icon={<span className="pda-icon text-xl">📟</span>} />
          <SidebarItem active={activeTab === 'chat'} onClick={() => handleTabChange('chat')} label={t.comms} icon={<span className="pda-icon text-xl">📡</span>} />
          <SidebarItem active={activeTab === 'missions'} onClick={() => handleTabChange('missions')} label={t.tasks} icon={<span className="pda-icon text-xl">📋</span>} />
          <SidebarItem active={activeTab === 'inventory'} onClick={() => handleTabChange('inventory')} label={t.inventory} icon={<span className="pda-icon text-xl">🎒</span>} />
          <SidebarItem active={activeTab === 'ranking'} onClick={() => handleTabChange('ranking')} label={t.ranking} icon={<span className="pda-icon text-xl">🏆</span>} />
          <SidebarItem active={activeTab === 'profile'} onClick={() => handleTabChange('profile')} label={t.dossier} icon={<span className="pda-icon text-xl">👤</span>} />
        </div>

        <div className="hidden md:block p-4 bg-black/40 border-t border-[#2a2d2a] font-mono text-[8px] space-y-1">
          <div className="text-[#4ade80]/40 uppercase font-bold mb-2">Logs do Sistema</div>
          {systemLogs.map((log, i) => (
            <div key={i} className="text-[#4ade80] opacity-80 truncate">> {log}</div>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-hidden relative bg-[#0c0d0c]">
        {renderContent()}
        <div className="pointer-events-none absolute inset-0 opacity-[0.03] bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
      </div>
    </PDAFrame>
  );
};

export default App;
