
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Moderates text content to ensure it's safe and follows the STALKER theme rules.
 * Returns true if safe, false if rejected.
 */
export const moderateText = async (text: string): Promise<{ safe: boolean; reason?: string }> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a moderation system for a STALKER roleplay social network. 
      Analyze the following text. 
      REJECT if: 
      1. It promotes real-world criminal activity or real violence.
      2. It contains sexual content or explicit harassment.
      3. It violates safety rules for real humans.
      ALLOW if:
      1. It's fictional roleplay about mutants, anomalies, artifacts, or in-game factions (STALKER game context).
      2. It's a normal social conversation.
      
      Text to analyze: "${text}"
      
      Respond in JSON format.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            safe: { type: Type.BOOLEAN },
            reason: { type: Type.STRING }
          },
          required: ["safe"]
        }
      }
    });
    const result = JSON.parse(response.text || '{"safe": false}');
    return result;
  } catch (error) {
    console.error("Moderation failed", error);
    return { safe: true }; // Fail open for connectivity issues, or false for maximum safety
  }
};

/**
 * Moderates an image (base64) to ensure it's appropriate.
 */
export const moderateImage = async (base64Data: string): Promise<{ safe: boolean; reason?: string }> => {
  try {
    // Remove data:image/xxx;base64, prefix
    const data = base64Data.split(',')[1] || base64Data;
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      // Always use the explicit { parts: [...] } structure for content with multiple modalities
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: data
            }
          },
          {
            text: "You are a content moderator for a S.T.A.L.K.E.R. themed app. Analyze this image. Reject if it contains: real-world graphic violence, gore (unless it looks like low-res game art), sexual content, or illegal activities. Allow if it looks like a stalker, post-apocalyptic scenery, or a normal profile photo. Respond in JSON with 'safe' (boolean) and 'reason' (string)."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            safe: { type: Type.BOOLEAN },
            reason: { type: Type.STRING }
          },
          required: ["safe"]
        }
      }
    });
    const result = JSON.parse(response.text || '{"safe": false}');
    return result;
  } catch (error) {
    console.error("Image moderation failed", error);
    return { safe: false, reason: "Network Error" };
  }
};

export const generateZoneNews = async () => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Generate 3 short 'Zone News' broadcast items in the style of S.T.A.L.K.E.R. barkeep radio. Mention factions like Loners, Duty, or Freedom. Focus on anomaly shifts, mutant sightings, or stalker rumors. Keep it gritty and atmospheric.",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              content: { type: Type.STRING },
              urgency: { type: Type.STRING, description: "Low, Medium, High" }
            },
            required: ["title", "content", "urgency"]
          }
        }
      }
    });
    return JSON.parse(response.text || '[]');
  } catch (error) {
    console.error("Failed to fetch zone news", error);
    return [];
  }
};

export const generateMissionFlavor = async (title: string, faction: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Create a S.T.A.L.K.E.R. mission description for a task titled "${title}" issued by the ${faction} faction. Include a realistic objective, a location (like Rostok, Zaton, or Agroprom), and a sense of danger. Keep it under 100 words.`,
    });
    return response.text;
  } catch (error) {
    return "The radio crackles with static. Intel currently unavailable.";
  }
};
