
class SoundService {
  private enabled: boolean = true;
  private isMuted: boolean = false;
  private sounds: Record<string, HTMLAudioElement> = {};
  private customAudio: HTMLAudioElement | null = null;

  constructor() {
    const SOUND_URLS = {
      pda_startup: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3',
      pda_click: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
      // Biblioteca de Mensagens Fixas
      msg_classic: 'https://assets.mixkit.co/active_storage/sfx/2358/2358-preview.mp3', // Chirp
      msg_digital: 'https://assets.mixkit.co/active_storage/sfx/2354/2354-preview.mp3', // Bip
      msg_military: 'https://assets.mixkit.co/active_storage/sfx/1636/1636-preview.mp3', // Burst
      
      pda_alarm: 'https://assets.mixkit.co/active_storage/sfx/951/951-preview.mp3',
      pda_news: 'https://assets.mixkit.co/active_storage/sfx/2570/2570-preview.mp3'
    };

    Object.entries(SOUND_URLS).forEach(([key, url]) => {
      this.sounds[key] = new Audio(url);
      this.sounds[key].preload = 'auto';
    });
  }

  setEnabled(enabled: boolean) {
    this.enabled = enabled;
  }

  setMuted(muted: boolean) {
    this.isMuted = muted;
  }

  // Permite injetar um novo áudio customizado vindo do perfil
  playCustom(base64: string) {
    if (!this.enabled || this.isMuted || !base64) return;
    
    try {
      if (this.customAudio) {
        this.customAudio.pause();
        this.customAudio = null;
      }
      this.customAudio = new Audio(base64);
      this.customAudio.play().catch(() => {});
    } catch (e) {
      console.error("Erro ao reproduzir som customizado", e);
    }
  }

  play(soundName: string, loop: boolean = false) {
    if (!this.enabled || this.isMuted) return;
    
    // Se o nome for 'msg_custom', quem chama deve usar playCustom
    if (this.sounds[soundName]) {
      const sound = this.sounds[soundName];
      sound.loop = loop;
      sound.currentTime = 0;
      sound.play().catch(() => {});
    }
  }

  stop(soundName: string) {
    if (this.sounds[soundName]) {
      this.sounds[soundName].pause();
      this.sounds[soundName].currentTime = 0;
    }
    if (this.customAudio) {
      this.customAudio.pause();
    }
  }
}

export const soundManager = new SoundService();
